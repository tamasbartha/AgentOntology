
# Endogenous Partitioning Project

## Structure

- `paper/` — NeurIPS-style LaTeX paper
- `paper/figures/` — generated figures
- `code/` — simulation package
- `notebooks/` — experiments

## Build Paper

Run:

```bash
pdflatex main.tex
```

inside `paper/`.

## Main Hypothesis

Systems undergo a phase transition in partition stability near:

Γ ≈ 1

where flow reconfiguration outpaces structural relaxation.
